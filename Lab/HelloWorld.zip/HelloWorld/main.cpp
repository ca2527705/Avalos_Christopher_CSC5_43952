/* 
 * File:   main.cpp
 * Author: Christopher Avalos
 * Purpose: Sup
 * Created on February 25, 2015, 10:39 AM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout<<"Hello World"<<endl;

    return 0;
}

